<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<!--Créer une page de formulaire dans laquelle on aura 2 champs de formulaire de type nombre.
-Afficher dans cette même page la somme des 2 champs avec un affichage du style :
La somme est égale à : valeur
vous pouvez vous inspirez des exemples de code page 34 et 35 (pour la version POST)
page 31 32 (pour la vsersion GET)-->


<!--Ne pas oublier d'entre des nombres sur la page pour voir le résulat "-->


<button><a href="index.php">Page 1</a></button>

<form action="" method="post">        
    <p>veuillez saisir un nombre :</p>         
    <input type="text" name="nombre">        
    <br>   
    <p>veuillez saisir un nombre :</p>         
    <input type="text" name="nombre1">       
    <input type="submit" value="Envoyer">    
</form> 



<?php
       if(isset($_POST['nombre'])){       
        $nombre = $_POST['nombre'];
        echo"<br>le nombre est : .'$nombre.'";    
        }

    if(isset($_POST['nombre1'])){       
        $nombre1 = $_POST['nombre1'];
        echo"<br>le nombre : .'$nombre1.'";    
        }

        $result = $nombre + $nombre1;

        echo "<br>Le resultat est : .'$result.'";

    ?>
</body>
</html>