<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<button><a href="page2.php">Page 2</a></button>

    <?php
        echo'<h1>Hello Word';

         //aller à la ligne
         echo '<br>';

        //Déclarer une variable
        $nbr = 2;
        $prenom = 'Leyla';
        $bool = false;

        //Afficher le type de la variable
        echo gettype($nbr);
        echo '<br>';

        //Afficher le contenu de la variable
        echo $nbr;
        echo '<br>';
        echo $prenom;
        echo $bool;


        $nbr1 = 2;
        $nbr2 = 6;
        $nbr3 = 2;
        $chaine = "je suis ";


        //Affichage de variable
        echo "<br> $nbr1+$nbr2";

        $nbr2+=$nbr1;


        //Après calcule 
        echo "<br>total = $nbr2";

        //Ecrire la valeur d’une variable
        echo "<br>affichage de la variable s’appelant \$nbr1=$nbr1";

        //Concaténation
        echo "<br>$chaine $prenom";

        //Simple quote 
        echo '<br>'.$chaine.' '.$prenom.'';




/////////////FONCTION//////////////////////////


        //Création d'une fonction
        function ma_function(){}

        ma_function();

        

        //Fonction avec paramètre
        function avec_parametre($a,$b){
            $result = $a - $b;
            return $result;
        }

        echo "<br>";
        echo avec_parametre(15,8);


        //Fonction qui prend un nombre à virgule en paramètre et qui retourne un entier 
        function arrondie(float $a){
            $b = round($a);
            return $b;
        }

        echo "<br>";
        echo arrondie(15.8);



        //Fonction retounant la somme des trois paramètres
        function somme($a,$b,$c){
            $result = $a + $b + $c;
            return $result;
        }

        echo "<br>";
        echo somme(15,8,10);



        //Fonction retounant la moyenne des paramètres
        function moyenne($a,$b,$c){
            $result = ($a + $b + $c) / 3;
            return $result;
        }

        echo "<br>";
        echo moyenne(15,8,10);



/////////////TABLEAU////////////////


        //déclaration d’un tableau vide (tab) 
        $tab = array() ; 


        //déclaration d’un tableau indexé numériquement 
        $tab1 = array(1,8,7,11) ; 
        
        //déclaration d’un tableau assiociatif 
        
        $identite = array(       
            'nom' => 'mithridate',       
            'prenom' => 'mathieu',       
            'age' => 41,       
            'estFormateur' => true
        ); 


        // Ajout d'un élément a un tableau indexé numériquement il sera ajouté à la dernière position.  
        $legumes[] = 'salade';
        
        // Ajout d'un élément a un tableau indexé numériquement à une position (2° position).  
        $legumes[1] = 'salade';  
        
        // Ajout de la taille de la personne dans le tableau associatif  
        $identite['taille'] = 180; 



        //création d'un tableau $prenoms 
        $prenoms[0] = 'Mathieu';
        $prenoms[1] = 'Sophie';
        $prenoms[2] = 'Florence';
        
        //ou
        $prenoms = array('Mathieu', 'Sophie', 'Florence'); 
        
        //parcours de tout le tableau
        foreach ($prenoms as $key => $value) {  echo '<br>'; 

        //Affiche le contenu de la case à chaque tour.  
        print_r($value);}
       
    ?>
    
</body>
</html>